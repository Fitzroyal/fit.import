package com.fit_import.Fit_Import;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FitImportApplicationTests {

	@Test
	void contextLoads() {
	}

}
