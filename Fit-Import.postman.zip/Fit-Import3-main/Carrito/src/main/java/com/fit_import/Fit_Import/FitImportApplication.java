package com.fit_import.Fit_Import;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FitImportApplication {

	public static void main(String[] args) {
		SpringApplication.run(FitImportApplication.class, args);
	}

}
